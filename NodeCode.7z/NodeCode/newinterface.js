const newinterface = require("readline");

const rl = new newinterface.createInterface({
    input: process.stdin,
    output: process.stdout,
});

rl.question("What is your name? ", function (response){
    console.log(`so your name is: ${response}`);
    rl.close();  
})

const prompt = require("prompt-sync")();

const input = prompt("please enter your name: ");
console.log(`oh so your name is: ${input}`);
